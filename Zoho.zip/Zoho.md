﻿Zoho Desk 

Es un software de servicio al cliente sensible al contexto, que lo ayuda a que sus clientes sean el centro de la empresa. 

Tiene como funciones :

Zoho Desk ayuda a los agentes a priorizar automáticamente los tickets de asistencia basados ​​en las interacciones con los clientes. Filtrar los tickets basados ​​en criterios como el tiempo de cierre, el estado o el tipo de cliente. Ahora su equipo sabrá qué tickets necesitan atención inmediata, y cuál puede ser manejado más adelante.

Editor de respuesta 

Los agentes responden mejor cuando tienen información contextualmente relevante sobre sus clientes. Zoho Desk aporta información de clientes de Zoho CRM directamente al ticket. Incluso el autor sugiere posibles soluciones, todos los agentes pueden ver la información desde un solo lugar dentro de Zoho Desk.

Al cliente se le puede ofrecer las distintas funciones de las cuales pueden hacer uso. 

Administración de tickets.

Zia

Autoservicio

Productividad de los agentes 

Automonitorización

Capacidad de ampliación

Información y efectos

Personalización 

Seguridad 

Se puede encontrar una gran variedad de herramientas las cuales puede hacer uso cada uno de los clientes en sus empresas. 

Es un software que a pesar de no ser gratuito, se puede ajustar a tus necesidades, por ello incorporaremos una imagen de los distintos planes que incluye. 

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.001.png)

Luego de que tengamos claro que plan queremos, nos resgitremos como tal como empresa. Llegaremos al siguiente punto.

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.002.png)

Una pequeña vista general de cada una de las cosas que vienen incluidas. 

Primero tenemos agregar tickets o importarlo, en nuestro caso hemos querido probar agregar uno nuevo, las opciones se ven de la siguiente manera.

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.003.png)


Es una buena manera de llevar un pequeño control de todos los tickets de nuestra empresa, al igual que una mejor organización.

Continuando viendo con todo lo que nos encontramos, tenemos el centro de asistencia, que se basa en un lugar donde se pueden publicar información, datos con los clientes.

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.004.png)

Al igual que existe una comunidad, en donde podemos mantener diferentes conversaciones con los clientes, recibir correos, publicaciones y demás.

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.005.png)

Un dato sumamente interesante es el apartado de los clientes, se trata de una agenda donde podemos ir guardando los distintos clientes que tengamos en la empresa. 

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.006.png)

El apartado más importante es el informe que se va creando de la empresa. Mostraremos como se ve, para una mejor explicación.

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.007.png)

Podemos encontrarnos con paneles de información 

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.008.png)

Por último tenemos los informes.

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.009.png)

Todo se puede adaptar según las necesidades de cada empresa, de manera que podemos personalizar lo que queremos conseguir.

Podemos controlar las actividades que tengamos en la empresa, llamadas, tareas y demás.

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.010.png)

Y por último en esta mini guía de Zoho, nos encontramos que a nuestros clientes le podemos ofrecer una asistencia técnica, de forma que se habilita un chat.

![](Aspose.Words.e1652a16-91af-424f-9e95-28d67846c4e2.011.png)

Es una gran software muy completo, para cumplir distintas necesidades dentro de una empresa mediana, para una mejor organización, un mayor control de distintas partes, que por cuenta propia sería más difícil de controlar. 





